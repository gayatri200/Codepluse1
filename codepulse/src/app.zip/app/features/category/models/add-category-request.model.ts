export interface AddCategoryRequest{
  name:string;
  urlHandle:string
}


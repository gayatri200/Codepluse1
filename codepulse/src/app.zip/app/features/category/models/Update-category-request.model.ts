
export interface UpdateCategoryRequest{
  name:string;
  urlHandle:string;
}
